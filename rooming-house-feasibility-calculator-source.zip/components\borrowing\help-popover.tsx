"use client"

import { useEffect, useRef, useState, type ReactNode } from "react"
import { HelpCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface HelpPopoverProps {
  label: string
  title?: string
  children: ReactNode
  triggerClassName?: string
}

/**
 * Dependency-free click-to-open help popover. Replaces the base-ui Popover
 * from the original export so the calculator drops that extra dependency.
 */
const POPOVER_WIDTH_PX = 320 // matches w-80
const VIEWPORT_MARGIN_PX = 12

export function HelpPopover({ label, title, children, triggerClassName }: HelpPopoverProps) {
  const [open, setOpen] = useState(false)
  const [offsetLeft, setOffsetLeft] = useState(0)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false)
    }
    document.addEventListener("mousedown", onDown)
    document.addEventListener("keydown", onKey)
    return () => {
      document.removeEventListener("mousedown", onDown)
      document.removeEventListener("keydown", onKey)
    }
  }, [open])

  useEffect(() => {
    if (!open || !ref.current) return
    // Clamp the popover's absolute viewport position so it never runs off either edge,
    // regardless of where the trigger sits on screen.
    const { left: triggerLeft } = ref.current.getBoundingClientRect()
    const width = Math.min(POPOVER_WIDTH_PX, window.innerWidth - VIEWPORT_MARGIN_PX * 2)
    const maxLeft = window.innerWidth - VIEWPORT_MARGIN_PX - width
    const desiredViewportLeft = Math.min(Math.max(triggerLeft, VIEWPORT_MARGIN_PX), maxLeft)
    setOffsetLeft(desiredViewportLeft - triggerLeft)
  }, [open])

  return (
    <span className="relative inline-flex" ref={ref as never}>
      <button
        type="button"
        aria-label={title ?? `What is ${label}?`}
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className={cn(
          "inline-flex size-4 items-center justify-center rounded-full opacity-70 transition-opacity hover:opacity-100 focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          triggerClassName,
        )}
      >
        <HelpCircle className="size-3.5" />
      </button>
      {open ? (
        <div
          style={{ left: offsetLeft }}
          className="absolute top-6 z-50 w-80 max-w-[calc(100vw-1.5rem)] rounded-lg border border-border bg-popover p-3 text-sm leading-relaxed text-popover-foreground shadow-lg"
        >
          <p className="mb-1 font-semibold text-foreground">{title ?? label}</p>
          <div className="text-muted-foreground [&_p]:mb-2 [&_p:last-child]:mb-0">{children}</div>
        </div>
      ) : null}
    </span>
  )
}
