# Rooming House Development Feasibility Calculator — source bundle

This is the source code for the feasibility calculator built for the Affordable House
Corp (AHC) website, extracted from `AIOS-AHC/outputs/website`. It's arranged with the
same relative paths it uses inside that Next.js (App Router) project, so you can drop
the folders straight back into a Next.js + TypeScript + Tailwind v4 project at the same
locations.

## Files

```
app/investor-resources/investment-calculator/page.tsx   Route that renders the calculator
components/feasibility/FeasibilityCalculator.tsx         Main UI: tabbed inputs + results dashboard
components/feasibility/line-item-editor.tsx               Add/remove/edit a list of $ cost line items
components/feasibility/room-category-editor.tsx           Add/remove/edit room types (rooms × weekly rent)
components/feasibility/status-dot.tsx                      Green/amber/red/grey traffic-light indicator
components/borrowing/input-field.tsx                       Shared numeric input (slider + typed box)
components/borrowing/metric-card.tsx                       Shared dashboard metric tile
components/borrowing/help-popover.tsx                      Shared click-to-open "?" explainer popover
lib/feasibility-calculations.ts                            Calculation engine + types (the core logic)
lib/borrowing-calculations.ts                               Only used for its qldTransferDuty() helper
lib/utils.ts                                                 cn() classname helper (clsx + tailwind-merge)
```

## What the calculator covers

Acquisition costs (incl. auto QLD transfer duty), development costs (demolition,
consultants, authority charges, building, room/common-area fit-out, contingency,
escalation), construction finance (average-drawn-balance interest, finance fees,
lease-up income shortfall), room income (multiple room categories, occupancy, vacancy
& collection loss, other income), operating expenses (variable %, fixed line items,
capital reserve), GST classification selector, depreciation & indicative tax (capital
works + plant & equipment, ownership entity, marginal rate), valuation (capitalisation
of income, value-per-room, or blended), development profit & margin, DSCR, interest
cover, break-even occupancy & rent, a 10-year annual projection with amortising or
interest-only debt, 5/10-year IRR, NPV and equity multiple, 13 stress-test scenarios,
editable investor targets with traffic-light scoring, an overall feasibility status,
a warnings panel, and a PDF export (via `jspdf`).

It deliberately simplifies two "advanced/ideally" items from the full 100+ section
spec it was built against: true month-by-month cash-flow scheduling and full BAS-timing
GST cash-flow modelling are collapsed into annual/aggregate estimates. This is disclosed
in the calculator's own disclaimer text.

## Dependencies

This code expects, in the host project's `package.json`:

- `next` (App Router, tested on 16.x), `react` / `react-dom` 19.x, `typescript` 5.x
- `tailwindcss` v4 (`@tailwindcss/postcss`)
- `lucide-react` — icons
- `clsx` and `tailwind-merge` — used by `lib/utils.ts`'s `cn()`
- `jspdf` — used for the "Export summary" PDF button (dynamically imported)

It also expects the shadcn-style CSS custom properties the host site defines in its
global stylesheet: `--background`, `--foreground`, `--primary`, `--primary-foreground`,
`--secondary`, `--muted`, `--muted-foreground`, `--accent`, `--card`, `--popover`,
`--border`, `--input`, `--ring`, `--destructive`, `--success`, `--warning`, mapped into
Tailwind via a `@theme inline` block, plus the `.range-slider` thumb styles used by
`input-field.tsx`. Copy the relevant block from the source project's `app/globals.css`
(or re-theme the colours to match your own brand) before dropping this in elsewhere.

All imports use the `@/` path alias (e.g. `@/lib/utils`) — make sure your
`tsconfig.json` has `"paths": { "@/*": ["./*"] }` (standard `create-next-app` default).

## Usage

Import and render the top-level component on any page:

```tsx
import { FeasibilityCalculator } from "@/components/feasibility/FeasibilityCalculator";

export default function Page() {
  return <FeasibilityCalculator />;
}
```
